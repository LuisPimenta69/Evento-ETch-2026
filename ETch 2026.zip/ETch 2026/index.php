<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evento ETch 2026</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">  
</head>  
<body>


<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">ETch 2026</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div> 
     <div class="container d-flex justify-content-center">
        <span class="navbar-brand mb-0 h1">ETch 2026</span>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div clas="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="#home">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#sobre">Sobre</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#programacao">Programação</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#inscricao">Inscrição</a>
                </li>
            </ul> 
           </div>
          </nav>
</header>



<main>
    <section id="home" class="text-center py-5">
        <article>
            <h1 class="text-center mb-4">Evento ETch 2026</h1>
            <div class="row text-center">
              <div class="cold-md-4"> 
                <h5> data</h5>
                <p>7 a 14 de Junho de 2026</p>
            </div>
            <div class="col-md-4">
                <h5>Local</h5>
                <p>Unis - Varginha, MG</p>
            </div>
            <div class="col-md-4">
                <h5>Descrição</h5>
                <p class="text-muted">Levando inovação, tecnologia e futuro em um dos maiores encontros tech do Brasil.</p>        
            </div>
        </article>
    </section>

<section id="palestrantes" class="container my-5">
    <h2 class="text-center mb-4">Palestrantes Confirmados</h2>
<?php
    $palestrantes = [
        ["nome" => "Eduardo Smith de Vasconcellos Suplicy", "confirmado" => true],
        ["nome" => "Mahatma Gandhe", "confirmado" => false],
        ["nome" => "Manoel Gomes", "confirmado" => true],
        ["nome" => "Arnold Schwarzenegger", "confirmado" => true],
        ["nome" => "Kung Lao", "confirmado" => false],
        ["nome" => "Danilo Gentili", "confirmado" => true],
    ];
?>

<div class="table-responsive">
    <table class="table table-striped table-hover text-center">
        <thead class="table-dark">
            <tr>
                <th>Nome</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($palestrantes as $palestrante) {
                echo "<tr>";
                echo "<td>{$palestrante['nome']}</td>";
                if ($palestrante["confirmado"]) {
                    echo "<td><span class='badge bg-success'>Confirmado</span></td>";
                } else {
                    echo "<td><span class='badge bg-secondary'>Não confirmado</span></td>";
                }
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</div>
</main>

<footer id="contato" class="bg-dark text-white text-center p-4 mt-5">
    <p class="mb-1">&copy; 2026 ETech. Todos os direitos reservados.</p>
    <p class="text-muted">Contato: contato@etech2026.com.br</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>